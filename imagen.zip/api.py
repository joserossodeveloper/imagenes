from flask import Flask, render_template, request, jsonify, url_for
import os

app = Flask(__name__)

# Ruta donde se guardarán las imágenes generadas
DIRECTORIO_IMAGENES = os.path.join(os.getcwd(), "static/imagenes_generadas")
os.makedirs(DIRECTORIO_IMAGENES, exist_ok=True)

@app.route('/')
def index():
    """Página principal."""
    return render_template('index.html')

@app.route('/api/generar_imagenes', methods=['POST'])
def generar_imagenes():
    """Genera imágenes en base a un prompt y retorna las URLs."""
    datos = request.get_json()

    prompt = datos.get("prompt")
    num_imagenes = datos.get("num_imagenes", 3)

    if not prompt:
        return jsonify({"error": "El prompt no puede estar vacío."}), 400

    try:
        imagenes = []
        for i in range(num_imagenes):
            # Simulación de generación de imágenes (reemplazar con Stable Diffusion u otra herramienta)
            nombre_imagen = f"imagen_{i+1}.png"
            ruta_imagen = os.path.join(DIRECTORIO_IMAGENES, nombre_imagen)

            # Aquí deberías insertar el código que genera las imágenes reales.
            # Por ahora, simulamos una generación con una imagen de ejemplo.
            with open(ruta_imagen, "wb") as f:
                f.write(b"\x89PNG\r\n\x1a\n")  # Crear un PNG vacío (solo como ejemplo)

            # Añadir URL de la imagen al listado
            url_imagen = url_for('static', filename=f"imagenes_generadas/{nombre_imagen}")
            imagenes.append(url_imagen)

        return jsonify({"imagenes": imagenes})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
