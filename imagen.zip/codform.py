from flask import Flask, request, jsonify, render_template, send_from_directory
from diffusers import StableDiffusionPipeline
import torch
import os
import uuid

app = Flask(__name__)

# Carpeta donde se guardan las imágenes generadas
CARPETA_SALIDA = 'static/imagenes_generadas'

# Crear la carpeta si no existe
if not os.path.exists(CARPETA_SALIDA):
    os.makedirs(CARPETA_SALIDA)

# Función para generar imágenes con Stable Diffusion
def generar_imagenes_con_stable_diffusion(prompt, num_imagenes=5, carpeta_salida=CARPETA_SALIDA):
    """
    Genera imágenes utilizando Stable Diffusion a partir de un prompt.
    
    Parámetros:
    - prompt (str): Descripción de la imagen a generar.
    - num_imagenes (int): Número de imágenes a generar.
    - carpeta_salida (str): Carpeta donde se guardarán las imágenes.
    """
    # Cargar el modelo preentrenado de Stable Diffusion
    pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")
    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    
    imagenes_generadas = []
    
    for i in range(num_imagenes):
        # Generar la imagen
        image = pipe(prompt).images[0]
        
        # Generar un nombre único para cada imagen
        nombre_archivo = os.path.join(carpeta_salida, f"{uuid.uuid4()}.png")
        image.save(nombre_archivo)
        imagenes_generadas.append(nombre_archivo)
    
    return imagenes_generadas

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generar_imagenes', methods=['POST'])
def generar_imagenes():
    prompt = request.form.get('prompt')
    if not prompt:
        return jsonify({"error": "El prompt es obligatorio"}), 400

    # Generar las imágenes
    imagenes_generadas = generar_imagenes_con_stable_diffusion(prompt, num_imagenes=3)

    # Crear una lista de URLs para las imágenes generadas
    imagenes_urls = [f"/static/imagenes_generadas/{os.path.basename(imagen)}" for imagen in imagenes_generadas]

    return render_template('index.html', prompt=prompt, imagenes=imagenes_urls)

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=8080)
