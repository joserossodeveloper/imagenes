from diffusers import StableDiffusionPipeline
import torch
import os

def generar_imagenes_con_stable_diffusion(prompt, num_imagenes=1, carpeta_salida="imagenes_artisticas"):
    """
    Genera imágenes utilizando Stable Diffusion a partir de un prompt.
    
    Parámetros:
    - prompt (str): Descripción de la imagen a generar.
    - num_imagenes (int): Número de imágenes a generar.
    - carpeta_salida (str): Carpeta donde se guardarán las imágenes.
    """
    # Crear la carpeta de salida si no existe
    if not os.path.exists(carpeta_salida):
        os.makedirs(carpeta_salida)
        print(f"Carpeta creada: {carpeta_salida}")
    
    # Cargar el modelo preentrenado de Stable Diffusion
    pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")
    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    
    for i in range(num_imagenes):
        # Generar la imagen
        image = pipe(prompt).images[0]
        
        # Guardar la imagen
        nombre_archivo = os.path.join(carpeta_salida, f"imagen_{i+1}.png")
        image.save(nombre_archivo)
        print(f"Imagen guardada: {nombre_archivo}")

# Generar imágenes con un prompt artístico
prompt = "A 3D heart made of roses with the word 'love' in the center, cinematic lighting, photorealistic"
generar_imagenes_con_stable_diffusion(prompt, num_imagenes=1, carpeta_salida="imagenes_artisticas")
